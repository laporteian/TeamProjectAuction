﻿namespace TeamProjectAuction
{
    public class Globals
    {
        public static AuctionDbContext AuctionContext;
    }
}